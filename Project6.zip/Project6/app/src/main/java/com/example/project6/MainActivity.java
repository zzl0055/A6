package com.example.project6;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    DataBaseManagement mDBManager;
    TextView mBalanceTv;
    Button mAddBtn, mSubBtn, mDateSelectBtn, mFromDateSelBtn, mToDateSelBtn, mFilterBtn, mResetBtn;
    EditText mPriceEdit, mItemEdit, mFromPriceEdit, mToPriceEdit;
    TableLayout mHistoryTl;
    SimpleDateFormat dateFormat;

    DecimalFormat df = new DecimalFormat("0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBalanceTv = (TextView) findViewById(R.id.balance);
        mDateSelectBtn = (Button) findViewById(R.id.selectDateBtn);
        mPriceEdit = (EditText) findViewById(R.id.editPrice);
        mItemEdit = (EditText) findViewById(R.id.editItem);
        mAddBtn = (Button) findViewById(R.id.btnAdd);
        mSubBtn = (Button) findViewById(R.id.btnSub);
        mHistoryTl = (TableLayout) findViewById(R.id.tableHistory);

        mFromDateSelBtn = (Button) findViewById(R.id.filterDateFromBtn);
        mToDateSelBtn = (Button) findViewById(R.id.filterDateToBtn);
        mFilterBtn = (Button) findViewById(R.id.filterBtn);
        mResetBtn = (Button) findViewById(R.id.filterResetBtn);
        mFromPriceEdit = (EditText) findViewById(R.id.editFromPrice);
        mToPriceEdit = (EditText) findViewById(R.id.editToPrice);

        mDBManager = new DataBaseManagement(this);

        dateFormat=new SimpleDateFormat(BalanceModel.DATE_FORMAT);

        AddBtnListener();
        GetHistory();
    }

    public void AddBtnListener(){
        mFilterBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DoFilter();
                    }
                }
        );
        mResetBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mFromDateSelBtn.setText("SELECT DATE");
                        mToDateSelBtn.setText("SELECT DATE");
                        mFromPriceEdit.setText("");
                        mToPriceEdit.setText("");
                        DoFilter();
                    }
                }
        );
        mFromDateSelBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Calendar calendar = Calendar.getInstance();
                        DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                                        calendar.set(Calendar.YEAR, year);
                                        calendar.set(Calendar.MONTH, month);
                                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                        String dateString = dateFormat.format(calendar.getTime());
                                        mFromDateSelBtn.setText(dateString);
                                    }
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        dialog.show();
                    }
                }
        );
        mToDateSelBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Calendar calendar = Calendar.getInstance();
                        DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                                        calendar.set(Calendar.YEAR, year);
                                        calendar.set(Calendar.MONTH, month);
                                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                        String dateString = dateFormat.format(calendar.getTime());
                                        mToDateSelBtn.setText(dateString);
                                    }
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        dialog.show();
                    }
                }
        );
        mDateSelectBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Calendar calendar = Calendar.getInstance();
                        DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                                        calendar.set(Calendar.YEAR, year);
                                        calendar.set(Calendar.MONTH, month);
                                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                                        String dateString = dateFormat.format(calendar.getTime());
                                        mDateSelectBtn.setText(dateString);
                                    }
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        dialog.show();
                    }
                }
        );

        mAddBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        double price = Double.parseDouble(mPriceEdit.getText().toString());
                        BalanceModel model = new BalanceModel();

                        try {
                            Date date = dateFormat.parse(mDateSelectBtn.getText().toString());
                            model.mDate = date.getTime();
                            model.mItem = mItemEdit.getText().toString();
                            model.mPrice = price;
                        } catch (ParseException e)
                        {

                        }

                        boolean result = mDBManager.createHistory(model);
                        if (result)
                            Toast.makeText(MainActivity.this, "Successfully Created", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "Failed to Create", Toast.LENGTH_LONG).show();
                        GetHistory();
                        ClearTextView();
                    }
                }
        );

        mSubBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        double price = -1 * Double.parseDouble(mPriceEdit.getText().toString());
                        BalanceModel model = new BalanceModel();
                        try {
                            Date date = dateFormat.parse(mDateSelectBtn.getText().toString());
                            model.mDate = date.getTime();
                            model.mItem = mItemEdit.getText().toString();
                            model.mPrice = price;
                        } catch (ParseException e)
                        {

                        }

                        boolean result = mDBManager.createHistory(model);
                        if (result)
                            Toast.makeText(MainActivity.this, "Successfully Created", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "Failed to Create", Toast.LENGTH_LONG).show();
                        GetHistory();
                        ClearTextView();
                    }
                }
        );
    }

    public void DoFilter(){
        ClearTableLayout();
        String fromDateString = mFromDateSelBtn.getText().toString();
        String toDateString = mToDateSelBtn.getText().toString();
        Date fromDate = null;
        Date toDate = null;
        try {
            fromDate = dateFormat.parse(fromDateString);
            toDate = dateFormat.parse(toDateString);
        } catch (ParseException e){

        }

        Cursor result = mDBManager.FilterTableData(fromDate==null?"SELECT DATE":(fromDate.getTime()+""), toDate==null?"SELECT DATE":(toDate.getTime()+""), mFromPriceEdit.getText().toString(), mToPriceEdit.getText().toString());
        StringBuffer buffer = new StringBuffer();
        Double balance = 0.0;

        while(result.moveToNext()){
            TableRow tr = new TableRow(this);
            TableRow.LayoutParams columnLayout = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
            columnLayout.weight = 1;

            TextView dateTv = new TextView(this);
            dateTv.setLayoutParams(columnLayout);
            long dateTime = result.getLong(2);
            Date date = new Date(dateTime);
            dateTv.setText(dateFormat.format(date));
            tr.addView(dateTv);

            TextView priceTv = new TextView(this);
            priceTv.setLayoutParams(columnLayout);
            priceTv.setText(result.getString(3));
            tr.addView(priceTv);

            TextView itemTv = new TextView(this);
            itemTv.setLayoutParams(columnLayout);
            itemTv.setText(result.getString(1));
            tr.addView(itemTv);

            mHistoryTl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            double price = Double.parseDouble(result.getString(3));
            balance += price;
        }
        MainActivity.this.mBalanceTv.setText("Current Balance: $" + df.format(balance));
    }

    public void GetHistory(){
        ClearTableLayout();
        Cursor result = mDBManager.pullData();
        StringBuffer buffer = new StringBuffer();
        Double balance = 0.0;

        while(result.moveToNext()){
            TableRow tr = new TableRow(this);
            TableRow.LayoutParams columnLayout = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
            columnLayout.weight = 1;

            TextView dateTv = new TextView(this);
            dateTv.setLayoutParams(columnLayout);
            long dateTime = result.getLong(2);
            Date date = new Date(dateTime);
            dateTv.setText(dateFormat.format(date));
            tr.addView(dateTv);

            TextView priceTv = new TextView(this);
            priceTv.setLayoutParams(columnLayout);
            priceTv.setText(result.getString(3));
            tr.addView(priceTv);

            TextView itemTv = new TextView(this);
            itemTv.setLayoutParams(columnLayout);
            itemTv.setText(result.getString(1));
            tr.addView(itemTv);

            mHistoryTl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            double price = Double.parseDouble(result.getString(3));
            balance += price;
        }
        MainActivity.this.mBalanceTv.setText("Current Balance: $" + df.format(balance));
    }

    public void ClearTextView(){
        MainActivity.this.mDateSelectBtn.setText("SELECT DATE");
        MainActivity.this.mPriceEdit.setText("");
        MainActivity.this.mItemEdit.setText("");
    }

    public void ClearTableLayout(){
        int count = mHistoryTl.getChildCount();
        for (int i = 1; i < count; i++) {
            mHistoryTl.removeViewAt(1);
        }
    }

}
