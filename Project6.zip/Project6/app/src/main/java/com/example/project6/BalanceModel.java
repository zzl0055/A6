package com.example.project6;

public class BalanceModel {
    public static final String DATE_FORMAT="MM/dd/yyyy";

    String mItem;
    long mDate;
    double mPrice;
}
